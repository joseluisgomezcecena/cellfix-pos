<div class="table-responsive">
    <table class="table table-bordered table-striped table-hover">
        <thead>
            <tr>
                <th style="width: 40px;">
                    <input type="checkbox" id="select-all-items">
                </th>
                <th>{{ __('inventorymultilocation::lang.product_name') }}</th>
                <th>{{ __('inventorymultilocation::lang.sku') }}</th>
                @if(request()->get('location_id') == 'all')
                    <th>{{ __('business.business_location') }}</th>
                @endif
                <th>{{ __('inventorymultilocation::lang.current_stock') }}</th>
                <th>{{ __('inventorymultilocation::lang.unit_cost') }}</th>
                <th>{{ __('sale.selling_price') }}</th>
                <th>{{ __('inventorymultilocation::lang.total_value') }}</th>
                <th>{{ __('inventorymultilocation::lang.stock_status') }}</th>
                <th>{{ __('inventorymultilocation::lang.last_updated') }}</th>
                <th>{{ __('messages.action') }}</th>
            </tr>
        </thead>
        <tbody>
            @forelse($inventory as $item)
                <tr data-product-id="{{ $item->product_id }}"
                    data-variation-id="{{ $item->variation_id }}"
                    data-location-id="{{ $item->location_id }}">
                    <td>
                        <input type="checkbox" class="inventory-checkbox">
                    </td>
                    <td>
                        <div class="product-name">{{ $item->product_name }}</div>
                        @if($item->variation_name && $item->variation_name != 'DUMMY')
                            <small class="text-muted variation-name">{{ $item->variation_name }}</small>
                        @endif
                        @if($item->category_name)
                            <br><span class="label label-default">{{ $item->category_name }}</span>
                        @endif
                        @if($item->brand_name)
                            <span class="label label-info">{{ $item->brand_name }}</span>
                        @endif
                    </td>
                    <td>
                        <code>{{ $item->sku ?: $item->sub_sku }}</code>
                    </td>
                    @if(request()->get('location_id') == 'all')
                        <td>
                            <span class="label label-primary">{{ $item->location_name ?: 'N/A' }}</span>
                        </td>
                    @endif
                    <td class="text-center">
                        <span class="current-stock">{{ number_format($item->qty_available ?: 0, 2) }}</span>
                        @if($item->unit_name)
                            <small class="text-muted">{{ $item->unit_name }}</small>
                        @endif
                    </td>
                    <td class="text-right">
                        @if($item->default_purchase_price)
                            <span class="display_currency" data-currency_symbol="true">{{ $item->default_purchase_price }}</span>
                        @else
                            <span class="text-muted">N/A</span>
                        @endif
                    </td>
                    <td class="text-right">
                        @if($item->default_sell_price)
                            <span class="display_currency" data-currency_symbol="true">{{ $item->default_sell_price }}</span>
                        @else
                            <span class="text-muted">N/A</span>
                        @endif
                    </td>
                    <td class="text-right">
                        @if($item->default_purchase_price && $item->qty_available)
                            <span class="display_currency" data-currency_symbol="true">{{ $item->default_purchase_price * $item->qty_available }}</span>
                        @else
                            <span class="text-muted">0.00</span>
                        @endif
                    </td>
                    <td class="text-center">
                        <span class="stock-indicator"
                              data-stock="{{ $item->qty_available ?: 0 }}"
                              data-alert-qty="{{ $item->alert_quantity ?: 0 }}">
                        </span>
                    </td>
                    <td class="text-center">
                        @if($item->last_updated)
                            <small class="text-muted">{{ \Carbon\Carbon::parse($item->last_updated)->diffForHumans() }}</small>
                        @else
                            <small class="text-muted">Never</small>
                        @endif
                    </td>
                    <td>
                        <div class="btn-group">
                            <button type="button" class="btn btn-xs btn-primary dropdown-toggle" data-toggle="dropdown">
                                {{ __('messages.actions') }} <span class="caret"></span>
                            </button>
                            <ul class="dropdown-menu" role="menu">
                                @if($item->qty_available > 0)
                                    <li>
                                        <a href="#" class="quick-transfer"
                                           data-product-id="{{ $item->product_id }}"
                                           data-variation-id="{{ $item->variation_id }}"
                                           data-location-id="{{ $item->location_id }}"
                                           data-product-name="{{ $item->product_name }}"
                                           data-current-stock="{{ $item->qty_available }}">
                                            <i class="fa fa-exchange"></i> {{ __('inventorymultilocation::lang.transfer') }}
                                        </a>
                                    </li>
                                @endif
                                <li>
                                    <a href="#" class="view-history"
                                       data-product-id="{{ $item->product_id }}"
                                       data-variation-id="{{ $item->variation_id }}"
                                       data-location-id="{{ $item->location_id }}">
                                        <i class="fa fa-history"></i> {{ __('lang_v1.view_history') }}
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="adjust-stock"
                                       data-product-id="{{ $item->product_id }}"
                                       data-variation-id="{{ $item->variation_id }}"
                                       data-location-id="{{ $item->location_id }}"
                                       data-current-stock="{{ $item->qty_available }}">
                                        <i class="fa fa-edit"></i> {{ __('stock_adjustment.stock_adjustments') }}
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="{{ request()->get('location_id') == 'all' ? '11' : '10' }}" class="text-center">
                        <div class="alert alert-info" style="margin: 20px 0;">
                            <i class="fa fa-info-circle"></i> {{ __('messages.no_data') }}
                        </div>
                    </td>
                </tr>
            @endforelse
        </tbody>
    </table>
</div>

@if($inventory->hasPages())
    <div class="text-center">
        {!! $inventory->appends(request()->query())->links() !!}
    </div>
@endif

<!-- Quick Transfer Modal -->
<div class="modal fade" id="quick-transfer-modal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">{{ __('inventorymultilocation::lang.transfer_stock') }}</h4>
            </div>
            <form id="quick-transfer-form">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <p><strong id="transfer-product-name"></strong></p>
                            <p>{{ __('inventorymultilocation::lang.current_stock') }}: <span id="transfer-current-stock"></span></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>{{ __('inventorymultilocation::lang.transfer_to') }}*</label>
                                <select name="to_location_id" class="form-control" required>
                                    <option value="">{{ __('messages.please_select') }}</option>
                                    @foreach($locations ?? [] as $location)
                                        <option value="{{ $location->id }}">{{ $location->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>{{ __('inventorymultilocation::lang.quantity_to_transfer') }}*</label>
                                <input type="number" name="quantity" class="form-control" min="0.01" step="0.01" required>
                                <input type="hidden" name="product_id">
                                <input type="hidden" name="variation_id">
                                <input type="hidden" name="from_location_id">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>{{ __('lang_v1.notes') }}</label>
                                <textarea name="notes" class="form-control" rows="2"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">{{ __('messages.cancel') }}</button>
                    <button type="submit" class="btn btn-primary">
                        {{ __('inventorymultilocation::lang.transfer') }}
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Select all checkbox
    $('#select-all-items').on('change', function() {
        $('.inventory-checkbox').prop('checked', $(this).is(':checked')).trigger('change');
    });

    // Quick transfer
    $(document).on('click', '.quick-transfer', function(e) {
        e.preventDefault();

        const productName = $(this).data('product-name');
        const currentStock = $(this).data('current-stock');
        const productId = $(this).data('product-id');
        const variationId = $(this).data('variation-id');
        const locationId = $(this).data('location-id');

        $('#transfer-product-name').text(productName);
        $('#transfer-current-stock').text(currentStock);

        const form = $('#quick-transfer-form');
        form.find('input[name="product_id"]').val(productId);
        form.find('input[name="variation_id"]').val(variationId);
        form.find('input[name="from_location_id"]').val(locationId);
        form.find('input[name="quantity"]').attr('max', currentStock);

        $('#quick-transfer-modal').modal('show');
    });

    // Quick transfer form submission
    $('#quick-transfer-form').on('submit', function(e) {
        e.preventDefault();

        const submitBtn = $(this).find('button[type="submit"]');
        submitBtn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Processing...');

        $.post('{{ route('inventory-multi.transfers.store') }}', $(this).serialize())
            .done(function(response) {
                if (response.success) {
                    toastr.success(response.message);
                    $('#quick-transfer-modal').modal('hide');
                    $('#inventory-filters').submit(); // Refresh table
                } else {
                    toastr.error(response.message);
                }
            })
            .fail(function() {
                toastr.error('{{ __('messages.something_went_wrong') }}');
            })
            .always(function() {
                submitBtn.prop('disabled', false).html('{{ __('inventorymultilocation::lang.transfer') }}');
            });
    });

    // Initialize display currency
    __currency_convert_recursively($('.table-responsive'));
});
</script>